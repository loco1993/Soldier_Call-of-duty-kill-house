﻿using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Threading;
using UnityEngine;

public class BryanScrip : MonoBehaviour
{

    float speed = 25;
    float speed2 = 60f;
    float rotSpeed= 80;
    float rotation = 0;
    float gravity = 3f;

    Vector3 moveDirection = Vector3.zero;
    CharacterController controller;

    Animator miAnimator;

    // Start is called before the first frame update
    void Start()
    {
        controller = GetComponent<CharacterController>();
        miAnimator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (controller.isGrounded)
        {

            //------------------- camina--------
            if (Input.GetKey(KeyCode.W))
            {
                miAnimator.SetInteger("IntCamina", 2);
                moveDirection = new Vector3(0, 0, 1);
                moveDirection = moveDirection * speed;
                moveDirection = transform.TransformDirection(moveDirection);
            }

            if (Input.GetKeyUp(KeyCode.W))
            {
                miAnimator.SetInteger("IntCamina", 0);
                moveDirection = new Vector3(0, 0, 0);
            }

            //------------------- corre--------
            if (Input.GetKey(KeyCode.E))
            {
                miAnimator.SetInteger("IntCorre", 1);
                moveDirection = new Vector3(0, 0, 1);
                moveDirection = moveDirection * speed2;
                moveDirection = transform.TransformDirection(moveDirection);
            }

            if (Input.GetKeyUp(KeyCode.E))
            {

                miAnimator.SetInteger("IntCorre", 0);
                moveDirection = new Vector3(0, 0, 0);
            }

            //------------------- salta--------


            if (Input.GetKey(KeyCode.T))
            {
                miAnimator.SetInteger("IntSalta", 4);
                moveDirection = new Vector3(0, 0, 0);
              
                moveDirection = transform.TransformDirection(moveDirection);
            }

            if (Input.GetKeyUp(KeyCode.T))
            {

                miAnimator.SetInteger("IntSalta", 0);
                moveDirection = new Vector3(0, 0, 0);
            }

        }
        rotation += Input.GetAxis("Horizontal") * rotSpeed * Time.deltaTime;
        transform.eulerAngles = new Vector3(0, rotation, 0);


        moveDirection.y -= gravity * Time.deltaTime;
        controller.Move(moveDirection * Time.deltaTime);
    }
}